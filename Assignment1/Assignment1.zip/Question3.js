/**
 * Created by courtneywright on 10/1/16.
 */

/**
 * I tried to write this so many times and couldn't fully understand how the string
 * was being passed so I was not able to get it. You can look at the commented code
 * to see the logic I was trying to implement
 */

function wohs (input) {

    // var newString = input.replace(/[^a-z0-9]/, "");
    // return cons(newString.slice(0, indexof(" ")), newString.length < 1 ? null : wohs(newString.slice(indexof(" "), newString.length - 1)));



    // var consStructure;
    // var stack = [];
    // var key;

    // if (typeof input[0] == 'list') {
    //     // stack.push(input[0]);
    //     consStructure = cons(wohs(input[0]), wohs(input[1]));
    //
    // } else {
    //     consStructure = cons(input[0], wohs(input.slice(1, input.length - 1)))
    // }

    // if (typeof input[0] == 'list' && key[input[0]] != true) {
    //     stack.push(input[0]);
    // } else if (typeof input[1] == 'list' && key[input[1]] != true) {
    //     stack.push(input[1]);
    // } else if(typeof consStucture == undefined) {
    //     var last = stack.pop();
    //     key[last] == true;
    //     consStructure = cons(last, null);
    // } else {
    //     consStructure = cons();
    // }



}